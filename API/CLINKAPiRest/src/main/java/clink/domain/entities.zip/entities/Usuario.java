package clink.domain.entities;

//APPROVED

public class Usuario {
    private Negocio negocio;
    private String nombreUsuario;
    private Usuario creador;
    private String Correo;
    private String rol;
    private String Contrasena;
    private String Calle;
    private String Colonia;
    private String codigoPostal;

    public Usuario(Negocio negocio, String nombreUsuario, Usuario creador, String correo, String rol,
                   String contrasena, String calle, String colonia, String codigoPostal) {
        this.negocio = negocio;
        this.nombreUsuario = nombreUsuario;
        this.creador = creador;
        Correo = correo;
        rol = rol;
        Contrasena = contrasena;
        Calle = calle;
        Colonia = colonia;
        this.codigoPostal = codigoPostal;
    }

    public Usuario() {
    }

    public Negocio getNegocio() {
        return negocio;
    }

    public void setNegocio(Negocio negocio) {
        this.negocio = negocio;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public Usuario getCreador() {
        return creador;
    }

    public void setCreador(Usuario creador) {
        this.creador = creador;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        rol = rol;
    }

    public String getContrasena() {
        return Contrasena;
    }

    public void setContrasena(String contrasena) {
        Contrasena = contrasena;
    }

    public String getCalle() {
        return Calle;
    }

    public void setCalle(String calle) {
        Calle = calle;
    }

    public String getColonia() {
        return Colonia;
    }

    public void setColonia(String colonia) {
        Colonia = colonia;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }
}
