package clink.adapters.in.dto;

public class LoginRequest {
    public String username;
    public String password;
}
